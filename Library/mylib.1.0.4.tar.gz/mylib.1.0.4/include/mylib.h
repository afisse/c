#ifndef mylib_h
#define mylib_h

void mylib_mul (int, int);
void mylib_add (int, int);
void mylib_sub (int, int);
void mylib_xxx (int, int);

#endif
