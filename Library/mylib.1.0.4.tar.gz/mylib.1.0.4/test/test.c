#include "mylib.h"

int main () {
  mylib_add (1,2);
  mylib_sub (1,2);
  mylib_mul (1,2);
  return 0;
}
